# Business Empire

Простой бизнес-симулятор на чистом HTML/CSS/JavaScript.

## Запуск на GitHub Pages

1. Создай новый публичный репозиторий на GitHub.
2. Загрузи в него `index.html`, `style.css`, `script.js` и `README.md`.
3. Открой **Settings → Pages**.
4. В разделе **Build and deployment** выбери **Deploy from a branch**.
5. Выбери `main` и папку `/ (root)`, затем **Save**.
6. Через некоторое время GitHub Pages даст ссылку на игру.

Прогресс сохраняется в браузере через `localStorage`, поэтому сервер для этой версии не нужен.
